//
//  cmdline.hpp
//  msdscript
//
//  Created by Ang Zhang on 1/12/22.
//

#ifndef cmdline_hpp
#define cmdline_hpp

#include <stdio.h>
#include <string>
#include "pointer.h"

//declaration of use_arguments
void use_arguments(int argc, char **argv);

#endif /* cmdline_hpp */
